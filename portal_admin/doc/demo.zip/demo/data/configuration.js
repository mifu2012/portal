﻿var configuration = 
{
"showPageNotes":true}